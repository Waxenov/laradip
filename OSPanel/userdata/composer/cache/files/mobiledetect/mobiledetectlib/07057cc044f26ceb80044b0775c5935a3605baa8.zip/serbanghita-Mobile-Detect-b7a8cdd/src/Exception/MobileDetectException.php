<?php

namespace Detection\Exception;

class MobileDetectException extends \Exception
{
}
