<?php

namespace Livewire\Features\SupportPagination;

trait WithoutUrlPagination
{
    //
}
