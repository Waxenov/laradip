<?php

namespace Laravel\Fortify\Contracts;

use Illuminate\Contracts\Support\Responsable;

interface PasswordUpdateResponse extends Responsable
{
    //
}
