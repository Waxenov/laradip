<?php

namespace Laravel\Fortify\Events;

class TwoFactorAuthenticationDisabled extends TwoFactorAuthenticationEvent
{
    //
}
