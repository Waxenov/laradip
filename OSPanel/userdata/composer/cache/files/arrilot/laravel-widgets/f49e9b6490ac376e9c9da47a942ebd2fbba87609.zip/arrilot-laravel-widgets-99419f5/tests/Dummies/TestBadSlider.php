<?php

namespace Arrilot\Widgets\Test\Dummies;

class TestBadSlider
{
    protected $slides = 6;

    public function run()
    {
    }
}
