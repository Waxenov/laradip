<?php

namespace Arrilot\Widgets\Misc;

use Exception;

class NamespaceNotFoundException extends Exception
{
}
