<?php

namespace Arrilot\Widgets\Test\Support;

class TestEncrypter
{
    public function encrypt($value)
    {
        return $value;
    }
}
